from django.urls import path
from hello import views

urlpatterns = [
    path("", views.home, name="home"),
    path("hello/<name>", views.hello_there, name="hello_there"),
    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),
    path("Consequences_of_Poor_Design/", views.Consequences_of_Poor_Design, name="Consequences_of_Poor_Design"),
    path("Pedestrians/", views.Pedestrians, name="Pedestrians"),
    path("Public_Transit/", views.Public_Transit, name="Public_Transit"),
    path("What_About_Cars/", views.What_About_Cars, name="What_About_Cars"),
    path("Real_World_Showcases/", views.Real_World_Showcases, name="Real_World_Showcases"),
    path("Other_Ways_To_Improve_Cities/", views.Other_Ways_To_Improve_Cities, name="Other_Ways_To_Improve_Cities"),
]