from django.shortcuts import render
import re
from django.utils.timezone import datetime
from django.http import HttpResponse

def home(request):
    return render(request, "hello/home.html")

def about(request):
    return render(request, "hello/about.html")

def contact(request):
    return render(request, "hello/contact.html")

def Pedestrians(request):
    return render(request, "hello/Pedestrians.html")

def Real_World_Showcases(request):
    return render(request, "hello/Real_World_Showcases.html")

def What_About_Cars(request):
    return render(request, "hello/What_About_Cars.html")

def Public_Transit(request):
    return render(request, "hello/Public_Transit.html")

def Other_Ways_To_Improve_Cities(request):
    return render(request, "hello/Other_Ways_To_Improve_Cities.html")

def Consequences_of_Poor_Design(request):
    return render(request, "hello/Consequences_of_Poor_Design.html")

def hello_there(request, name):
    return render(
        request,
        'hello/hello_there.html',
        {
            'name': name,
            'date': datetime.now()
        }
    )

    # Filter the name argument to letters only using regular expressions. URL arguments
    # can contain arbitrary text, so we restrict to safe characters only.
    match_object = re.match("[a-zA-Z]+", name)

    if match_object:
        clean_name = match_object.group(0)
    else:
        clean_name = "Friend"

    content = "Hello there, " + clean_name + "! It's " + formatted_now
    return HttpResponse(content)